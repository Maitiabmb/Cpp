#include <iostream>


int main()
{
    // a "hello world" program
    
    std::cout << "hello world" << '\n';
}
